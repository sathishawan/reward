import React, { Component } from 'react';
import { Link} from 'react-router-dom';



class AllEmployee extends Component {
    constructor(props){
      super(props);
      this.state = {
        employee: [],
        isLoaded:false
      };
    }


    componentDidMount(){
      fetch('http://localhost:8080/api/getEmployee')
      .then(res=>res.json())
      .then(json=>{
      this.setState({
      isLoaded:true,
      employee:json,
      })
      });
      }
    

      render(){
        // var {employee}=this.state;
      
        return(
          <body>
        <div className="App">

        <h1 >Rewards Program  <i class="fa fa-trophy" id="color"></i></h1> 
    

        <center>
        <table>
        <thead>
        <tr>
          <th colspan="7" class="colspan">All Employee List</th>
        </tr>
        <tr>
        <th>Employee No</th>
        <th>Employee Name</th>
        <th>Point Value</th>
        <th>Point Donate</th>
        <th>Point Received</th>
        <th>Point Expired</th>
        <th>Last Timestamp</th>
        
        </tr>
           
        {this.state.employee.map((employees)=>
  
  <tr>
 <td>{employees.emp_no}</td> 
 <td>{employees.emp_name}</td> 
 
 {employees.points.map((sub)=>

 <td>{sub.point_value}</td>
 
 )}
 {employees.points.map((sub)=>

<td>{sub.point_donate}</td>

)}
{employees.points.map((sub)=>

<td>{sub.point_received}</td>

)}
{employees.points.map((sub)=>

<td>{sub.point_expired}</td>

)}
{employees.points.map((sub)=>

<td>{sub.last_timestamp}</td>

)}
  </tr>

)
}


        </thead>
     

        </table>
        </center>
        
       
     
     
      
    
        
        </div>
        </body>
      
        )
        
        }
}

export default AllEmployee;


